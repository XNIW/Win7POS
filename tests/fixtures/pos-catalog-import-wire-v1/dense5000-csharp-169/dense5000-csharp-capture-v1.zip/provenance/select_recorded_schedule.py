"""Read-only pilot inspection; writes a separate source-index selection ledger.

Does not rewrite a schedule, request, response, SQLite database or repository file.
"""
import hashlib
import json
import math
from pathlib import Path
import zipfile

EVIDENCE = Path(r"C:/Dev/_codex-evidence/win7pos-post-pr122-20261009")
ARCHIVE = EVIDENCE / "interop/admin-dense-pilot-002934d3/source/contracts/pos-catalog-import-recovery-multipart-v1/interop/dense5000-c827-actual-pilot/dense5000-c827-actual-pilot-schedule.zip"
ZIP_SHA = "1111be524982933d98a2e25f8b3245f526efb454d1fbd1727b9f0eed9c29d95b"
SCHEDULE_SHA = "a02c9e004dc48f45e6879e67a6b167debbf7b3108cec692d5847ed0eb7e7d821"
OUTPUT = Path(__file__).with_name("selection.manifest.json")


def sha(data):
    return hashlib.sha256(data).hexdigest()


archive_bytes = ARCHIVE.read_bytes()
assert sha(archive_bytes) == ZIP_SHA
with zipfile.ZipFile(ARCHIVE) as archive:
    schedule_bytes = archive.read("schedule.json")
    assert sha(schedule_bytes) == SCHEDULE_SHA
    schedule = json.loads(schedule_bytes)
    assert schedule["schemaVersion"] == "win7pos-phased-admin-schedule-v1"
    records = schedule["requests"]
    assert len(records) == 210
    responses = []
    for record in records:
        assert Path(record["responseFile"]).name == record["responseFile"]
        raw = archive.read(record["responseFile"])
        assert "sha256:" + sha(raw) == record["responseSha256"]
        responses.append((json.loads(raw), len(raw)))

    at = 0
    selected = []

    def take(action, **selector):
        global at
        for index in range(at, len(records)):
            record = records[index]
            if record["action"] == action and all(record["selector"].get(key) == value for key, value in selector.items()):
                at = index + 1
                selected.append(index)
                assert record["httpStatus"] == 200, (index, record["httpStatus"])
                return responses[index][0]
        raise AssertionError(("required exchange absent", action, selector, at))

    original_id = "9bdb44a6-1d95-45cb-82bc-e5e11ffba1e9"
    plan_upload_id = "6a099899-dce2-4e47-8d8e-74510a4897cb"
    plan_id = "0cf18f5d-bca2-47c8-8291-5b4f350910e0"

    def upload(upload_id, raw_length):
        # Client chunk size is fixed; logical normalization page lengths are not.
        take("upload", phase="manifest", uploadId=upload_id, offset=0)
        take("upload", phase="seal", uploadId=upload_id)
        for part_index in range(math.ceil(raw_length / 262144)):
            take("upload", phase="bytes", uploadId=upload_id, partIndex=part_index)

    def finish(action, upload_id):
        response = take(action, phase="prepare", uploadId=upload_id)
        seen = set()
        while response["status"] == "normalizing":
            stage = response.get("stage", response.get("phase"))
            if stage == "complete":
                assert response.get("nextCursor") is None
                return take(action, phase="complete", uploadId=upload_id)
            cursor = response["nextCursor"]
            assert isinstance(cursor, int) and not isinstance(cursor, bool)
            assert (stage, cursor) not in seen
            seen.add((stage, cursor))
            selector = {"phase": "normalize", "uploadId": upload_id, "cursor": cursor}
            if action == "plan":
                selector["stage"] = stage
            response = take(action, **selector)
        return response

    upload(original_id, 4857436)
    assert finish("finalize", original_id)["status"] == "verified"
    assert take("receipt", verifiedOriginalId=original_id)["status"] == "not_found"
    upload(original_id, 4857436)
    assert finish("finalize", original_id)["status"] == "verified"
    retirement = take("retire", verifiedOriginalId=original_id)
    assert retirement["status"] == "retired" and retirement["oldIdentityBlocked"] and retirement["retiredAt"]
    upload(plan_upload_id, 5940971)
    planned = finish("plan", plan_upload_id)
    assert planned["status"] == "planned" and planned["partCount"] == 10 and planned["itemCount"] == 5000
    assert sum(part["itemCount"] for part in planned["parts"]) == 5000
    for part_index in range(10):
        final = take("apply", planId=plan_id, partIndex=part_index)
        assert final["status"] == "accepted" and final["complete"] is True
        assert final["offset"] == 0 and final["limit"] == final["totalItemCount"]
        assert final["acceptedPartCount"] == part_index + 1
    assert final["parentStatus"] == "complete" and final["acceptedPartCount"] == 10
    assert len(selected) == 169
    selected_set = set(selected)

    def source_record(index):
        record = records[index]
        return {"sourceIndex": index, **record, "responseByteLength": responses[index][1]}

    def excluded_reason(index):
        record = records[index]
        action = record["action"]
        phase = record["selector"].get("phase")
        if action == "receipt-page":
            return "additional_QA_receipt_page_after_apply_already_returned_complete_ACK"
        if action == "receipt":
            return "additional_QA_lookup_not_issued_by_happy_service_sequence"
        if action == "retire":
            return "additional_QA_idempotent_retirement_replay"
        if action == "plan" and phase == "complete" and index > selected[-1]:
            return "additional_QA_cached_plan_readback_not_used_as_delivery_completion"
        if action == "finalize" and phase == "complete" and index in (72, 73):
            return "additional_QA_complete_after_second_prepare_already_returned_verified"
        return "additional_QA_exact_phase_retry_not_issued_by_happy_service_sequence"

    result = {
        "schemaVersion": "win7pos-phased-pilot-selection-v1",
        "scope": "Happy-path C# capture input selection from real Admin/isolated PostgreSQL replies; synthetic outer authentication. Not fresh-database exact-wire replay or C# reingest qualification.",
        "inputCheckpoint": "51964ac2ec242a6f0f75c0ee65d44ad57a99a352",
        "sourceArchiveCommit": "002934d3",
        "sourceAdminCommit": schedule["sourceCommit"],
        "archiveFileName": ARCHIVE.name,
        "archiveSha256": ZIP_SHA,
        "archiveByteLength": len(archive_bytes),
        "sourceScheduleFile": "schedule.json",
        "sourceScheduleSha256": SCHEDULE_SHA,
        "sourceResponseCount": len(records),
        "selectedCount": len(selected),
        "selected": [source_record(index) for index in selected],
        "excludedCount": len(records) - len(selected),
        "excluded": [{**source_record(index), "reason": excluded_reason(index)} for index in range(len(records)) if index not in selected_set],
        "derivation": "Logical normalize requests follow recorded nextCursor and phase/stage. Source indexes only increase; no record is reused and no source response is rewritten.",
        "observedFinalApply": {key: final[key] for key in ("planId", "partIndex", "acceptedPartCount", "partCount", "parentStatus", "complete")},
        "selectionScriptSha256": sha(Path(__file__).read_bytes()),
    }
    assert not OUTPUT.exists(), "Preserve previous evidence; use a fresh output location."
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"path": str(OUTPUT), "sha256": sha(OUTPUT.read_bytes()), "selected": len(selected), "excluded": len(records) - len(selected)}))
