import collections
import datetime
import hashlib
import json
import pathlib
import sqlite3
import subprocess
import xml.etree.ElementTree as ET
import zipfile

BASE = pathlib.Path('C:/Dev/_codex-evidence/win7pos-post-pr122-20261009')
PROOF = BASE / 'large-proof'
OUT = PROOF / 'dense5000-transfer'
CAPTURE = PROOF / 'dense5000-csharp-capture-v1'
INPUT = PROOF / 'phased-inputs-v2/dense-5000'
SELECTION = PROOF / 'dense5000-selection'
PILOT = BASE / 'interop/admin-dense-pilot-002934d3/source/contracts/pos-catalog-import-recovery-multipart-v1/interop/dense5000-c827-actual-pilot'
REPO = pathlib.Path('C:/Users/xniw9/.codex/worktrees/post-pr122-recovery/Win7POS')

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def dump(path, value):
    if path.exists():
        raise RuntimeError('Refusing to overwrite: ' + str(path))
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def record(path, name):
    return {'path': name, 'byteLength': path.stat().st_size, 'sha256': sha(path)}

capture = json.loads((CAPTURE / 'capture.manifest.json').read_text(encoding='utf-8'))
selection = json.loads((SELECTION / 'selection.manifest.json').read_text(encoding='utf-8'))
assert len(capture['requests']) == 169
assert selection['selectedCount'] == 169 and selection['excludedCount'] == 41
assert capture['sourceSelectionSha256'] == sha(SELECTION / 'selection.manifest.json')
assert capture['sourceScheduleSha256'] == sha(SELECTION / 'archive210/schedule.json')
assert sha(PILOT / 'dense5000-c827-actual-pilot-schedule.zip') == '1111be524982933d98a2e25f8b3245f526efb454d1fbd1727b9f0eed9c29d95b'
for request in capture['requests']:
    source = capture['sourceSchedule']['requests'][request['sourceIndex']]
    for key in ('action', 'selector', 'httpStatus', 'responseSha256'):
        assert source[key] == request[key], (request['index'], key)
    assert source['responseFile'] == request['sourceResponseFile']
    for kind in ('request', 'response'):
        path = CAPTURE / request[kind + 'File']
        assert sha(path) == request[kind + 'Sha256'].removeprefix('sha256:')
        assert path.stat().st_size == request[kind + 'ByteLength']
    assert (CAPTURE / request['responseFile']).read_bytes() == (SELECTION / 'archive210' / source['responseFile']).read_bytes()
assert max(row['requestByteLength'] for row in capture['requests']) <= 512 * 1024

con = sqlite3.connect((CAPTURE / 'recovered.sqlite').as_uri() + '?mode=ro', uri=True)
status = dict(con.execute('SELECT status,COUNT(*) FROM catalog_import_outbox GROUP BY status'))
assert status == {'acked': 10, 'recovered': 1}
original, original_hash = con.execute('SELECT payload_json,payload_hash FROM catalog_import_outbox WHERE id=1').fetchone()
assert original.encode('utf-8') == (INPUT / 'original.persisted.json').read_bytes()
assert original_hash == sha(INPUT / 'original.persisted.json')
assert con.execute('SELECT COUNT(*) FROM catalog_import_prepared_plan').fetchone()[0] == 0
assert con.execute('SELECT COUNT(*) FROM products WHERE unitPrice=1200 AND remote_product_id IS NOT NULL').fetchone()[0] == 5000
assert con.execute('SELECT COUNT(*) FROM product_meta WHERE stock_qty=1.25').fetchone()[0] == 5000
assert con.execute('SELECT COUNT(*) FROM product_price_history').fetchone()[0] == 10000
assert con.execute('SELECT COUNT(*) FROM product_price_history WHERE remote_price_id IS NOT NULL').fetchone()[0] == 10000
assert con.execute("SELECT COUNT(*) FROM product_price_history WHERE UPPER(TRIM(type))='PURCHASE' AND new_price=900").fetchone()[0] == 5000
assert con.execute("SELECT COUNT(*) FROM product_price_history WHERE UPPER(TRIM(type))='RETAIL' AND new_price=1200").fetchone()[0] == 5000
con.close()

ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
trx = ET.parse(PROOF / 'dense5000-capture-first.trx')
counters = trx.find('.//t:Counters', ns).attrib
assert counters['total'] == counters['passed'] == '1' and counters['failed'] == counters['notExecuted'] == '0'
result = trx.find('.//t:UnitTestResult', ns).attrib

files = {}
for path in CAPTURE.iterdir():
    if path.is_file():
        files['capture/' + path.name] = path
for name in ('original.persisted.json', 'plan.document.json', 'original.sqlite', 'trust.synthetic.json', 'inputs.manifest.json'):
    files['inputs/' + name] = INPUT / name
files['provenance/pilot-original-schedule.zip'] = PILOT / 'dense5000-c827-actual-pilot-schedule.zip'
files['provenance/pilot-manifest.json'] = PILOT / 'pilot-manifest.json'
files['provenance/pilot-README.md'] = PILOT / 'README.md'
for name in ('selection.manifest.json', 'select_recorded_schedule.py', 'static-helper-pricekind-finding.json'):
    files['provenance/' + name] = SELECTION / name
files['source/capture-helper.before.cs'] = SELECTION / 'capture-helper-before-pricekind.cs'
files['source/capture-helper.after.cs'] = OUT / 'capture-helper.after.cs'
files['source/capture-helper.delta.patch'] = OUT / 'capture-helper.delta.patch'
for path in (SELECTION / 'capture-runner').iterdir():
    if path.is_file():
        files['runner/' + path.name] = path
files['runner/dense5000-capture-first.trx'] = PROOF / 'dense5000-capture-first.trx'
files['provenance/package_capture.py'] = pathlib.Path(__file__)

before = sha(files['source/capture-helper.before.cs'])
after = sha(files['source/capture-helper.after.cs'])
assert before == 'ba87da421af4046dbbaccde6f2de7f8ca76c70509de7d5f18a33a53dcef0c74c'
assert after == '8abbd9e6a8c61ef94bc0a682002c673b3b6734cfca39e66b324781e8776f46ba'
assert after == sha(REPO / 'tests/Win7POS.Core.Tests/Data/CatalogImportRecoveryPhasedInteropEvidenceTests.cs')
receipt = {
    'schemaVersion': 'win7pos-dense-csharp-capture-receipt-v1',
    'createdUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Happy-path C# capture driven by unchanged actual Admin pilot replies; fresh Admin exact-wire replay and reingest are pending.',
    'clientHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'inputCheckpoint': '51964ac2ec242a6f0f75c0ee65d44ad57a99a352',
    'adminPilotArchiveCommit': '002934d3',
    'adminPilotSource': '54a7a3cf7c01e60ea032d9d7444e9b445fa36511',
    'adminPilotSqlSha256': 'c827afcaeae4fc4270b0b0d5078c4d7ce7084ff9d315bde4492f46982d3a80cf',
    'outerAuth': 'Synthetic trusted session, token/lease and schema fixtures; actual archived parser/handler/isolated SQL replies unchanged.',
    'flow': ['PrepareAsync', 'RetireAsync', 'CommitAsync', 'SyncPendingAsync one part at a time, ten parts'],
    'test': {'firstAttempt': True, 'result': result, 'counters': counters, 'trx': 'runner/dense5000-capture-first.trx', 'runnerIsTransient': True, 'permanentPositiveCiAdded': False},
    'requests': {'count': 169, 'maxUtf8BodyBytes': max(row['requestByteLength'] for row in capture['requests']), 'httpLimitBytes': 524288,
                 'actions': dict(collections.Counter(row['action'] for row in capture['requests'])), 'sourceResponses': 210, 'excludedAdditionalPilotQaResponses': 41,
                 'selectionSha256': capture['sourceSelectionSha256'], 'sourceScheduleSha256': capture['sourceScheduleSha256'], 'requestJsonManuallyAdjusted': False},
    'observedClientState': {'rows': 5000, 'parts': 10, 'ackedParts': 10, 'parentStatus': 'recovered', 'unresolved': False,
        'productIdsComparedToPilotReplies': 5000, 'priceIdsComparedToPilotReplies': 10000, 'historyRows': 10000,
        'stockEach': '1.25', 'retailEach': '1200', 'purchaseEach': '900', 'originalBytesAndHashUnchanged': True,
        'partialAckCannotCloseParent': True, 'preparedPlanRows': 0, 'outboxStatusCounts': status},
    'sourceDelta': {'path': 'tests/Win7POS.Core.Tests/Data/CatalogImportRecoveryPhasedInteropEvidenceTests.cs', 'beforeSha256': before, 'afterSha256': after,
        'changes': ['Optional explicit immutable 169-of-210 response selection with complete selected/excluded partition validation', 'Strict purchase/retail enum normalization and canonical uppercase SQL comparison'], 'productFilesChanged': []},
    'binaryProvenance': [record(REPO / path, path) for path in (
        'src/Win7POS.Core/bin/Release/netstandard2.0/Win7POS.Core.dll', 'src/Win7POS.Data/bin/Release/netstandard2.0/Win7POS.Data.dll',
        'tests/Win7POS.Core.Tests/bin/Release/net10.0/Win7POS.Core.Tests.dll')],
    'backupRetainedOnAsusNotDuplicatedInTransfer': [record(path, str(path)) for path in (CAPTURE / 'backups').iterdir() if path.is_file()],
    'pending': ['Fresh equivalent isolated Admin database replay of the 169 exact captured C# request bodies under the final server SQL',
                'C# reingest of newly captured actual replay responses with exact ID/value/receipt/closure assertions', 'Pinned permanent positive CI proof after that roundtrip'],
    'notClaimed': ['Dense failure/crash/retry/lost-response scenarios', '59999-row upper-limit completion', 'Shared TEST deployment', 'Worker or physical Win7 qualification']
}
dump(OUT / 'capture.receipt.json', receipt)
files['capture.receipt.json'] = OUT / 'capture.receipt.json'

readme = '''# Dense 5000: exact C# wire capture for fresh Admin replay

First run: **1/1 PASS, 0 skipped**, 10.273 seconds, official Win7POS Core.Tests runner with the evidence-only external test import preserved under `runner/`.

This bundle contains 169 unmodified HTTP request bodies emitted by the production C# client and the 169 unmodified actual Admin pilot replies that drove them. The flow is Prepare, explicit retirement, commit, and ten individual sync/ACK operations on a read-only copy of the pinned source SQLite. The parent closes only after all ten ACKs. Exact 5,000 product IDs and 10,000 price IDs, unchanged history count, stock 1.25, retail 1200, purchase 900, immutable original bytes/hash, and cleared pending plan/queue were checked. See `capture/sqlite-readback.json` and the recovered SQLite.

Scope: happy-path capture from actual archived replies with synthetic outer trusted-session/auth fixtures. This is not yet proof that a fresh Admin database accepted these exact C# requests. Dense crash/retry/lost-response cases, the 59,999-row upper limit, deployed Worker/shared TEST, and physical Win7 are not claimed.

## Replay inputs

`capture/capture.manifest.json` binds each exact request/response byte file, route action, status, length, SHA256, and original pilot source index. Send each request body unchanged to the corresponding `/api/pos/catalog/import-recovery/<action>` through the official parser/handler and fresh equivalent isolated PostgreSQL fixtures. Do not replace the body with a parsed/reserialized object before the parser. Capture new actual response bytes/status/hash indexed against the exact request SHA256; preserve the original pilot replies separately. The C# follow-up will consume these new actual replies and verify mappings and state again.

`inputs/` preserves the builder/SQLite original, deterministic precommit plan, source SQLite, trust fixture, and original input manifest. The input manifest also lists source files outside this minimal transfer; only files explicitly listed in this bundle manifest are transferred. Source timestamps, identities and plan IDs are fixed in those inputs. There is no JSON rewriting or synthetic receipt/fence substitution in this capture.

## Selection and provenance

The untouched 210-response source ZIP and its manifest are under `provenance/`. `selection.manifest.json` explicitly partitions 169 selected source records and 41 additional pilot QA records, with every action, selector, status, byte length and response SHA. Selection follows actual server nextCursor/stage and full-ACK responses. The excluded cached plan readback is not delivery authority. All selected replies remain byte-identical to the source ZIP; request bodies are newly emitted by C#.

`source/` freezes the sole test-helper change, before/after SHA and patch. Its prior lowercase-vs-uppercase price-kind assertion issue was a static helper finding corrected before the first run, not a dense test failure and not the separate Admin upper-limit timeout. No product file changed. The transient test source and MSBuild import, first TRX, capture receipt, and exact binary hashes are retained. The test assembly for this evidence run includes that transient test; no permanent positive CI fixture has been introduced yet.

`bundle.manifest.json` inventories every transferred file except itself. The external transfer manifest additionally binds the ZIP SHA256. SQLite files are snapshots, never live databases. A verified pre-change backup remains on Asus; its path/size/hash are in the receipt rather than duplicating it in the ZIP.
'''
if (OUT / 'README.md').exists():
    raise RuntimeError('Refusing README overwrite')
(OUT / 'README.md').write_text(readme, encoding='utf-8')
files['README.md'] = OUT / 'README.md'
manifest = {'schemaVersion': 'win7pos-dense-csharp-transfer-v1', 'scope': receipt['scope'], 'fileCount': len(files),
            'files': [record(path, name) for name, path in sorted(files.items())]}
dump(OUT / 'bundle.manifest.json', manifest)
files['bundle.manifest.json'] = OUT / 'bundle.manifest.json'
zip_path = OUT / 'dense5000-csharp-capture-v1.zip'
if zip_path.exists():
    raise RuntimeError('Refusing ZIP overwrite')
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(files.items()):
        archive.write(path, name)
with zipfile.ZipFile(zip_path) as archive:
    assert len(archive.namelist()) == len(files)
    for row in manifest['files']:
        raw = archive.read(row['path'])
        assert len(raw) == row['byteLength'] and hashlib.sha256(raw).hexdigest() == row['sha256']
transfer = {'schemaVersion': 'win7pos-dense-csharp-transfer-envelope-v1', 'archive': record(zip_path, zip_path.name),
    'bundleManifest': record(OUT / 'bundle.manifest.json', 'bundle.manifest.json'), 'receipt': record(OUT / 'capture.receipt.json', 'capture.receipt.json'),
    'captureManifest': record(CAPTURE / 'capture.manifest.json', 'capture/capture.manifest.json'),
    'clientHelperBeforeSha256': before, 'clientHelperAfterSha256': after, 'archiveFileCount': len(files), 'archiveVerifiedEveryFile': True,
    'scope': receipt['scope'], 'pending': receipt['pending']}
dump(OUT / 'transfer.manifest.json', transfer)
print(json.dumps(transfer, indent=2))
