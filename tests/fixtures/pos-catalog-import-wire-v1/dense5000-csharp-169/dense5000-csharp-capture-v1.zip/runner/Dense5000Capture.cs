using System;
using System.IO;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Win7POS.Core.Tests.Data;

// Temporary evidence runner imported only into the repository's real test
// project. A permanent positive fixture awaits fresh Admin exact-wire replay.
[TestClass]
public sealed class Dense5000CaptureRun
{
    [TestMethod]
    public async Task Dense5000_RealPilotResponses_CaptureUnchangedCSharpServiceWire()
    {
        const string evidence = "C:/Dev/_codex-evidence/win7pos-post-pr122-20261009";
        const string zip = evidence + "/interop/admin-dense-pilot-002934d3/source/contracts/pos-catalog-import-recovery-multipart-v1/interop/dense5000-c827-actual-pilot/dense5000-c827-actual-pilot-schedule.zip";
        const string inputs = evidence + "/large-proof/phased-inputs-v2/dense-5000";
        const string selection = evidence + "/large-proof/dense5000-selection/selection.manifest.json";
        Assert.AreEqual("1111be524982933d98a2e25f8b3245f526efb454d1fbd1727b9f0eed9c29d95b", Hash(zip));
        Assert.AreEqual("ee6b2caaac8dd1abe7491b48f5021bd0e0b3b7a538173b1bf324ec0a6dc3480c", Hash(selection));
        Assert.AreEqual("9f5f164646d70b5376a90a257bcfd5984811eabe21a8e665bbca909251c46e10", Hash(inputs + "/original.persisted.json"));
        Assert.AreEqual("f5200da9c5aece8f0b2b35f44e891f14c12cb1a411c17806653bcec5f374bba5", Hash(inputs + "/plan.document.json"));
        Assert.AreEqual("72436b352e3656b3662cbec055d7d7f1a865a0e1059997730f907c95f3e5f550", Hash(inputs + "/original.sqlite"));
        await CatalogImportRecoveryPhasedInteropEvidenceTests.CaptureRecordedDenseRecoveryAsync(inputs,
            evidence + "/large-proof/dense5000-selection/archive210", evidence + "/large-proof/dense5000-csharp-capture-v1", 5000, selection);
    }

    private static string Hash(string path)
    {
        using var stream = File.OpenRead(path);
        return Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant();
    }
}
